import cv2
import imutils

cap = cv2.VideoCapture("D:/Projects/2021-22_projects/2021_R_projects/drowsiness_detection/new_dataset/WhatsApp Video 2022-05-08 at 12.23.56 PM 2.mp4")
cap.set(3,640)
cap.set(4,480)

count = 0
while(True):
    try:
        ret, frame = cap.read()
        frame = imutils.resize(frame, width=800)
        count += 1
        cv2.imshow('frame', frame)
        p = "dataset/Grooming_left/" + "{}.png".format(count)
        cv2.imwrite(p, frame)
        print(count)
        c = cv2.waitKey(1)
        if c & 0xFF == ord('q'):
            break
    except:
        cap.release()
        cv2.destroyAllWindows()
        print("[info] Done")
        break
cv2.destroyAllWindows()
