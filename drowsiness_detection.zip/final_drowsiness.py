# import the necessary packages
import tkinter as tk
from tkinter import *
from PIL import Image,ImageTk
from tkinter.filedialog import askopenfilename
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
import numpy as np
import imutils
import cv2

print("[INFO] loading network...")
model = load_model("final.model")

classes = {
            1:'Grooming Left',
            2:'Grooming Right',
            3:'Driking Water Left',
            4:'Driking Water Right',
            5:'Makeup',
            6:'Mobile left',
            7:'Mobile Right',
            8:'Talking Left',
            9:'Talking Right'
           }

#Main Windows of GUI
window = tk.Tk()
window.title("Drowsiness")

window.geometry('900x450')
window.configure(background='white')

message = tk.Label(window, text="Drowsiness", bg="white", fg="black", width=38,height=2, font=('times', 30, 'italic bold '))
message.place(x=5, y=10)

def notify():
    sc1.destroy()

def ok_screen():
    global sc1
    sc1 = tk.Tk()
    sc1.geometry('300x100')
    sc1.title('Status')
    sc1.configure(background='snow')
    Label(sc1,text='File Selected',fg='red',bg='white',font=('times', 16, ' bold ')).pack()
    Button(sc1,text='OK',command=notify,fg="black"  ,bg="lawn green"  ,width=9  ,height=1, activebackground = "Red" ,font=('times', 15, ' bold ')).place(x=90,y= 50)

def on_closing():
    from tkinter import messagebox
    if messagebox.askokcancel("Quit", "Do you want to quit?"):
        window.destroy()
window.protocol("WM_DELETE_WINDOW", on_closing)

def select_video():
    global video_path
    video_path = askopenfilename(filetypes=[("Video File",'')])
    ok_screen()

def predict():
    video_capture = cv2.VideoCapture(video_path)

    # set the ration of main video screen
    video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    while True:
        ret,img = video_capture.read()
        orig = img.copy()
        # pre-process the image for classification
        image = cv2.resize(img, (28, 28))
        image = image.astype("float") / 255.0
        image = img_to_array(image)
        image = np.expand_dims(image, axis=0)

        # load the trained convolutional neural network


        # classify the input image
        label = model.predict(image)[0]

        idx = np.argmax(label)
        percentage = round(label[idx] * 100,4)
        #print(percentage)
        final_prediction = classes[idx+1]


        # draw the label on the image
        output = imutils.resize(orig, width=400)
        cv2.putText(output, final_prediction + ":" +str(percentage) ,(10, 25),  cv2.FONT_HERSHEY_SIMPLEX,
                0.7, (0, 0, 255), 2)
        # show the output image
        cv2.imshow("Output", output)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    video_capture.release()
    cv2.destroyAllWindows()



mask_cam = tk.Button(window, text="Predict",fg="black",command=predict ,bg="lawn green"  ,width=20  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
mask_cam.place(x=200, y=300)
    
get_video_Button = tk.Button(window, text="Select Video for Prediction",command=select_video,fg="black"  ,bg="yellow"  ,width=50 ,height=2, activebackground = "Red" ,font=('times', 10, ' bold '))
get_video_Button.place(x=320, y=150)

quitWindow = tk.Button(window, text="Quit", command=on_closing  ,fg="black"  ,bg="lawn green"  ,width=20  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
quitWindow.place(x=500, y=300)

window.mainloop()
