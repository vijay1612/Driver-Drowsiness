import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
import os
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.preprocessing.image import img_to_array
import random
from glob import glob
import cv2
import imutils

images = []
folder_path = 'dataset'

classes = [name for name in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, name))]
print(classes.sort())

# import image data and combine labels
def load_data(image_size, image_dir):
    X = []
    y=[]
    labels =[]
    for root, folder, files in os.walk(image_dir):
        #print(folder)
        images.append(root)
        for f in files:
            #print(image_dir)
            if f.lower().endswith('.jpg') or f.lower().endswith('.png') or f.lower().endswith('.jpeg'):
                #print(root, folder, f)
                img = load_img(f'{root}/{f}', target_size=(image_size,image_size,3))
                img_array = img_to_array(img, dtype='uint8')
                X.append(img_array)
                
                # get y
                labels.append(root[8:])
                
                
             
                
    return np.array(X, dtype=np.uint8), np.array(y), np.array(labels)

print("[INFO] Please Wait! Loading Images")
data_x, data_y, labels = load_data(224, folder_path)

print(len(data_x))

plt.figure(figsize=(4,4))
plt.bar(0,len(data_x))
plt.xticks([])

plt.ylabel('Toatl Images') 
plt.xlabel('Total number of sampels') 
plt.figure(figsize=(10,4))
plt.hist(labels,bins = len(classes),histtype='bar',rwidth=0.9)

plt.xticks(rotation='vertical')
plt.tight_layout()
#plt.savefig("Number Of Samples.png")
plt.show()

def plotImages(multipleImages):
    #print(multipleImages)
    r = random.sample(multipleImages, 9)
    plt.figure(figsize=(8,8))
    plt.subplot(331)
    plt.imshow(cv2.imread(r[0])[:,:,::-1]); plt.axis('off')
    plt.subplot(332)
    plt.imshow(cv2.imread(r[1])[:,:,::-1]); plt.axis('off')
    plt.subplot(333)
    plt.imshow(cv2.imread(r[2])[:,:,::-1]); plt.axis('off')
    plt.subplot(334)
    plt.imshow(cv2.imread(r[3])[:,:,::-1]); plt.axis('off')
    plt.subplot(335)
    plt.imshow(cv2.imread(r[4])[:,:,::-1]); plt.axis('off')
    plt.subplot(336)
    plt.imshow(cv2.imread(r[5])[:,:,::-1]); plt.axis('off')
    plt.subplot(337)
    plt.imshow(cv2.imread(r[6])[:,:,::-1]); plt.axis('off')
    plt.subplot(338)
    plt.imshow(cv2.imread(r[7])[:,:,::-1]); plt.axis('off')
    plt.subplot(339)
    plt.imshow(cv2.imread(r[8])[:,:,::-1]); plt.axis('off')
    plt.show()

def plotGrayHist(multipleImages):
    r = random.sample(multipleImages, 1)
    image = cv2.imread(r[0])
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # compute a grayscale histogram
    hist = cv2.calcHist([image], [0], None, [256], [0, 256])
    # matplotlib expects RGB images so convert and then display the image
    # with matplotlib
    plt.figure()
    plt.axis("off")
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_GRAY2RGB))
    # plot the histogram
    plt.figure()
    plt.title("Grayscale Histogram")
    plt.xlabel("Bins")
    plt.ylabel("# of Pixels")
    plt.plot(hist)
    plt.xlim([0, 256])
    plt.show()

def plotColorHist(multipleImages):
    r = random.sample(multipleImages, 1)
    # load the input image from disk
    image = cv2.imread(r[0])
    # split the image into its respective channels, then initialize the
    # tuple of channel names along with our figure for plotting
    chans = cv2.split(image)
    colors = ("b", "g", "r")
    plt.figure()
    plt.title("'Flattened' Color Histogram")
    plt.xlabel("Bins")
    plt.ylabel("# of Pixels")
    # loop over the image channels
    for (chan, color) in zip(chans, colors):
            # create a histogram for the current channel and plot it
            hist = cv2.calcHist([chan], [0], None, [256], [0, 256])
            plt.plot(hist, color=color)
            plt.xlim([0, 256])
    # create a new figure and then plot a 2D color histogram for the
    # green and blue channels
    fig = plt.figure()
    ax = fig.add_subplot(131)
    hist = cv2.calcHist([chans[1], chans[0]], [0, 1], None, [32, 32],
            [0, 256, 0, 256])
    p = ax.imshow(hist, interpolation="nearest")
    ax.set_title("2D Color Histogram for G and B")
    plt.colorbar(p)
    # plot a 2D color histogram for the green and red channels
    ax = fig.add_subplot(132)
    hist = cv2.calcHist([chans[1], chans[2]], [0, 1], None, [32, 32],
            [0, 256, 0, 256])
    p = ax.imshow(hist, interpolation="nearest")
    ax.set_title("2D Color Histogram for G and R")
    plt.colorbar(p)
    # plot a 2D color histogram for blue and red channels
    ax = fig.add_subplot(133)
    hist = cv2.calcHist([chans[0], chans[2]], [0, 1], None, [32, 32],
            [0, 256, 0, 256])
    p = ax.imshow(hist, interpolation="nearest")
    ax.set_title("2D Color Histogram for B and R")
    plt.colorbar(p)
    # finally, let's examine the dimensionality of one of the 2D
    # histograms
    print("2D histogram shape: {}, with {} values".format(
            hist.shape, hist.flatten().shape[0]))
    hist = cv2.calcHist([image], [0, 1, 2],
            None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    print("3D histogram shape: {}, with {} values".format(
            hist.shape, hist.flatten().shape[0]))
    # display the original input image
    plt.figure()
    plt.axis("off")
    plt.imshow(imutils.opencv2matplotlib(image))
    # show our plots
    plt.show()
     
for i in range(1,len(images)):
    #make sure image format
    multipleImages = glob(images[i] + '\\' + "*.png")
    plotImages(multipleImages)
    plotGrayHist(multipleImages)
    plotColorHist(multipleImages)
